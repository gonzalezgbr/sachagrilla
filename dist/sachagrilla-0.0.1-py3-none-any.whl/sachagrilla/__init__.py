# __init__.py

"""Paquete de nivel superior de sachagrilla."""

__version__ = '0.0.1'
