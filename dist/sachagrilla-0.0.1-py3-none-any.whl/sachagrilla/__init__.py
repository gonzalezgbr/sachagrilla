# __init__.py

"""Paquete de nivel superior de sachagrilla."""

from pathlib import Path


__version__ = '0.0.1'
MAIN_MODULE_BASEPATH = Path(__file__).parent.resolve()
